M3 Fellowship brand assets

Mark: the M3 ligature, a band with a translucent hatched fill.
  m3-mark-mint.svg / .png         transparent, for dark grounds
  m3-mark-*-on-dark.svg / .png    on the station ground, with clear space
  Use it at least 24 px tall. Keep clear space of half its height around it.
  Don't recolour, stretch, outline or put it on light or busy backgrounds.

Colours
  Ground      #0B0B0C
  Panel       #111213
  Text        #EDEBE6
  Mint        #5FE3C0   (default accent)
  Blue        #5B92DD   (alternate theme)

Type
  IBM Plex Mono for labels and data (caps labels write O as Ø)
  Newsreader for headlines

Also: favicon.svg, apple-touch-icon.png (180 px), og.png (1200x630 share image).
