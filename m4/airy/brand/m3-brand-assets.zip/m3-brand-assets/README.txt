M3 Fellowship brand assets

Logo: the M³ wordmark.
  m3-logo-light.svg / .png     off-white, for dark grounds
  m3-logo-dark.svg / .png      near-black, for light grounds
  m3-logo-on-dark.svg / .png   on the dark ground, with clear space
  Use it at least 20 px tall. Keep clear space of half its height around it.
  Don't recolour, stretch or outline it.

Colours
  Ground      #0B0B0C
  Panel       #111213
  Text        #EDEBE6
  Mint        #5FE3C0   (default accent)
  Blue        #5B92DD   (alternate theme)

Type
  IBM Plex Mono for labels and data (caps labels write O as Ø)
  Newsreader for headlines

Also: favicon.svg, apple-touch-icon.png (180 px), og.png (1200x630 share image).
